insert into food (name,description,price,picture) values ('Salmon','Fried salmon',3.99,'salmon.jpeg');
insert into food (name,description,price,picture) values ('Skinny chips','Chips like you would have in Mc Donalds',1.2,'thinchips.jpeg');
insert into food (name,description,price,picture) values ('Chips','Thicker chips for those ladies and gentlemen with bigger appetites',1.5,'fatchips.jpeg');
insert into food (name,description,price,picture) values ('Cod','A slice of battered cod: great with chips',3.5,'cod.jpeg');
insert into food (name,description,price,picture) values ('Calimari','A plate of breaded fried Squid tentacles. Yummy!',7,'calimari.jpeg');
