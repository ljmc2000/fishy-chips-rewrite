all images in this folder were pulled from google images for educational purpouses.
